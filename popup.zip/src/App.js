import React from "react";
import "./App.css";
import Popup from "./Components/Popup/Popup";

function App() {
  return (
    <div className="App">
      <Popup />
    </div>
  );
}

export default App;
